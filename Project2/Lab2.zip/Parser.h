#pragma once
#include <vector>
#include "Token.h"

class Parser{
private:
    std::vector<Token> tokens;

public:
    Parser(const std::vector<Token>& vt): tokens(vt){}
    
    TokenType tokenType() const{
        return tokens.at(0).getType();
    }

    void advanceToken(){
        tokens.erase(tokens.begin());
    }

    void throwError(){
        std::cout << "Error" << endl;
    }

    void parse(){

    }

    void match(TokenType t) {
        cout << "match: " << t << endl;
        if (tokenType() == t){
            advanceToken();
        }
        else{
            throwError();
        }
    }

    //idList -> COMMA ID idList | lambda
    void idList() {
        if (tokenType() == COMMA){
            match(COMMA);
            match(ID);
            idList();
        } 
        else{
        // lambda
        }
    }

    void scheme(){
        if(tokenType() == ID){
            match(ID);
            match(LEFT_PAREN);
            match(ID);
            idList();
            match(RIGHT_PAREN);
        }
        else{
            throwError();
        }
    }

};