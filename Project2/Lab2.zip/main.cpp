#include "Token.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include "Scanner.h"
#include "Parser.h"
using namespace std;

int main(int argc, char* argv[]){
    if(argc <= 1){
        cout << "No input file given";
    }
    ifstream is(argv[1]);
    string input;
    
    if(!is){
        cout << "Failed to open" << endl;
    }

    vector<Token> tokens = {
        Token(ID,"Ned",2),
        //Token(LEFT_PAREN, "(",2),
        Token(ID,"Ted",2),
        Token(COMMA, ",",2),
        Token(ID,"Zed",2),
        Token(RIGHT_PAREN,")",2),
    };
    Parser parser(tokens);
    
    parser.scheme();
}